package br.com.cotemig.mycar.controller;

import br.com.cotemig.mycar.model.Car;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/cars")
public class CarController extends HttpServlet {
    @Override
        protected  void doPost(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
            String tipo = req.getParameter("type");

            Car car = convertRequestBodyToCar(req);
            String corpo = tipo.equals("XML") ?
                    getXML(car) :
                    getJSON(car);
            resp.setContentType(
                    tipo.equals("XML") ?
                            "application/xml; charset=utf-8" :
                            "application/json; charset=utf-8"
            );
            resp.getWriter().print(corpo);
        }
        private Car convertRequestBodyToCar(HttpServletRequest req){
            Car car = new Car();

            // Dados Pessoais
            car.setModel(req.getParameter("model"));
            car.setYear(req.getParameter("year"));
            car.setSeats(Integer.valueOf((req.getParameter("seats"))));
            car.setPrice(Double.valueOf(req.getParameter("price")));
            return car;
        }

        private String getXML(Car car){
            StringBuilder xml = new StringBuilder();
            xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            xml.append("<car>\n");
            xml.append(String.format("\t<model>%s</model>\n", car.getModel()));
            xml.append(String.format("\t<year>%s</year>\n", car.getYear()));
            xml.append(String.format("\t<seats>%s</seats>\n", car.getSeats()));
            xml.append(String.format("\t<price>%s</price>\n", car.getPrice()));
            xml.append("</car>\n");

            return xml.toString();
        }
        private String getJSON(Car car){
            StringBuilder json = new StringBuilder();
            json.append("{\n");
            json.append("\t\"car\" :{\n");
            json.append(String.format("\t\t\"%s\" : \"%s\",\n", "model", car.getModel()));
            json.append(String.format("\t\t\"%s\" : \"%s\",\n", "year", car.getYear()));
            json.append(String.format("\t\t\"%s\" : \"%s\",\n", "seats", car.getSeats()));
            json.append(String.format("\t\t\"%s\" : \"%s\"\n", "price", car.getPrice()));
            json.append("\t}\n");
            json.append("}\n");
            return json.toString();
        }
}
