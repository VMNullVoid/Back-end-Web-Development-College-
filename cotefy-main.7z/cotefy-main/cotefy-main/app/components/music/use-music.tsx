"use client";

import { useCallback, useEffect, useState } from "react";
import { Music } from "./music";

export default function useMusic() {
    const [musics, setMusics] = useState<Music[]>([]);
    const [music, setMusic] = useState<Music | null>(null);
    const [error, setError] = useState<string | null>(null);

    const load = useCallback(async () => {
        try {
            const response = await fetch("http://localhost:8080/musics");
            const data = await response.json();
            if (response.ok) {
                setMusics(data);
            } else {
                setError(data);
            }
        } catch (error) {
            setError(`Erro ao carregar as músicas! ${error}`);
        }
    }, []);

    useEffect(() => {
        load();
    }, []);

    const handleDelete = async (id: number) => {
        try {
            setError(null);
            const response = await fetch(`http://localhost:8080/musics/${id}`, {
                method: "DELETE",
            });
            if (response.ok) {
                load();
            } else {
                setError("Música não encontrada!");
            }
        } catch (error) {
            setError(`Erro ao excluir a música! ${error}`);
        }
    }

    const handleView = async (id: number) => {
        const music = musics.find((music) => music.id === id);
        if (music) {
            setMusic(music);
        }
    }

    const handleCloseView = async () => {
        setMusic(null);
    }    

    return {
        musics,
        error,
        music,
        handleDelete,
        handleView,
        handleCloseView,
    };
}