export interface Music {
    id: number;
    name: string;
    artist: string;
    recordLabel: string;
    duration: number;
    coverUrl: string;
}