"use client";

import { faCircleXmark, faEye, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Image from "next/image";
import styles from "./music.module.css";
import useMusic from "./use-music";

export default function ListMusic() {

    const { musics, error, music, handleDelete, handleView, handleCloseView } = useMusic();

    return (
        <div>
            {error && (<p className={styles.errorMessage}>{error}</p>)}
            {musics.length === 0 && (<div className={styles.emptyMessage}><p>Nenhuma música encontrada!</p></div>)}
            <section className={styles.listMusics}>
                {musics.length > 0 ?
                    musics.map((music) => (
                        <article key={music.id}>
                            <Image src={music.coverUrl} alt={music.name} width={150} height={150} />
                            <div>
                                <h2>{music.name}</h2>
                                <p>{music.artist}</p>
                            </div>
                            <nav>
                                <button onClick={(e) => handleView(music.id)}><FontAwesomeIcon icon={faEye} /></button>
                                <button onClick={(e) => handleDelete(music.id)}><FontAwesomeIcon icon={faTrash} /></button>
                            </nav>
                        </article>
                    )) : ""
                }
            </section>
            {music && (
                <section className={styles.musicDetails}>
                    <section>
                        <nav>
                            <h2>Detalhes da Música</h2>
                            <button onClick={(e) => handleCloseView()}><FontAwesomeIcon icon={faCircleXmark} /></button>
                        </nav>
                        <section>
                            <Image src={music.coverUrl} alt={music.name} width={300} height={300} />
                            <div>
                                <h2>Música: {music.name}</h2>
                                <p>Artista: {music.artist}</p>
                                <p>Duração: {music.duration} segundos</p>
                                <p>Gravadora: {music.recordLabel}</p>
                            </div>
                        </section>
                    </section>
                </section>
            )}
        </div>
    )
}