import type { Metadata } from "next";
import { Roboto } from "next/font/google";
import "./globals.css";

import { config } from '@fortawesome/fontawesome-svg-core';
import '@fortawesome/fontawesome-svg-core/styles.css';
config.autoAddCss = false;

const roboto = Roboto({
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Cotefy",
  description: "Cotefy Music Catalog",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-br">
      <body className={roboto.className}>
        <header>
          <h1>Cotefy</h1>
        </header>
        <main>
          {children}
        </main>
        <footer>
          <p>{new Date().getFullYear()} - Prof. Fernando Belém - Desenvolvimento Web Backend</p>
        </footer>
      </body>
    </html>
  );
}
