import ListMusic from "./components/music/list-music";

export default function Home() {
  return (
    <>
      <ListMusic/>
    </>
  );
}
