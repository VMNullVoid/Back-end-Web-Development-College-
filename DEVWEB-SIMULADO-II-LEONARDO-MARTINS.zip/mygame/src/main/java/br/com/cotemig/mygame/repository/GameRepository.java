package br.com.cotemig.mygame.repository;

import br.com.cotemig.mygame.model.Game;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameRepository extends JpaRepository<Game, Long> {
}
