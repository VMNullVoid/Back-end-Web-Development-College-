package br.com.cotemig.mygame.controller;

import br.com.cotemig.mygame.model.Game;
import br.com.cotemig.mygame.repository.GameRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/games")
@CrossOrigin
public class GameController {
    private GameRepository gameRepository;
    /*
    * findAll: HTTP GET - path: “/games” - retorne todos os games cadastrados em formato JSON.
findById: HTTP GET - path: “/games/{id}” - retorne apenas um game pelo id em formato JSON. Caso não exista, retorne o status 404.
*/
    @GetMapping
    public ResponseEntity<List<Game>> index(){
//ResponseEntity retorna uma entidade de determinado tipo
        List<Game> Game = gameRepository.findAll();
        return ResponseEntity.ok(Game);
        // ResponseEntity.badRequest();
    }

    @GetMapping("/{id}") //fala que vai variar com base no ID
    public ResponseEntity<Game> get(@PathVariable("id") Long id){
        Optional<Game> car =gameRepository.findById(id);
        if(car.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(car.get());
    }
}
