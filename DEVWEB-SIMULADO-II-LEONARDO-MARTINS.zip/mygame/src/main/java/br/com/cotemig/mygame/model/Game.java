package br.com.cotemig.mygame.model;

import jakarta.persistence.*;
import org.springframework.data.annotation.Id;

import java.util.Objects;
@Entity
@Table(name = "games")
public class Game {
    /*
    * id: Long, chave primária, auto incremento;
name: String, obrigatório, tamanho de 50 caracteres;
studio: String, obrigatório, tamanho de 50 caracteres;
price: Double, obrigatório;
Nome da tabela: games;
Atentar com as annotations do Spring Data JPA;
Implementar getters and setters;
Implementar construtores (sem parâmetros e com parâmetros, exceto o id);
Implementar os métodos equals e hashCode considerando apenas o atributo id.
*/
    @jakarta.persistence.Id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 50)
    private String name;
    @Column(nullable = false, length = 50)
    private String studio;
    @Column(nullable = false)
    private Double price;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Game() {
    }

    public Game(String name, String studio,Double price) {
        this.name = name;
        this.studio = studio;
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Game game = (Game) o;
        return Objects.equals(id, game.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }




}
