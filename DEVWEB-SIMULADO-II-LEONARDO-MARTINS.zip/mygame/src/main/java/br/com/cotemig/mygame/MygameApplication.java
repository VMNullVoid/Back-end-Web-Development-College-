package br.com.cotemig.mygame;

import br.com.cotemig.mygame.model.Game;
import br.com.cotemig.mygame.repository.GameRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;



@SpringBootApplication
public class MygameApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(MygameApplication.class, args);
    }

    @Autowired
    private GameRepository GameRepository;

    private Logger batata = LoggerFactory.getLogger(MygameApplication.class);
    @Override
    public void run(String... args) throws Exception {
        long gamesQtde = GameRepository.count();
        if(gamesQtde == 0){
            //no lugar de carsQtde podemos usar carRepository.count()
            //se a lista estiver vazia de cara vai inserir esses carros no BD
            List<Game> scars = new ArrayList<Game>();
            scars.add(new Game("Lamborghini Gallardo","", 2000000D));
            scars.add(new Game("Lamborghini Gallardo","", 2000000D));
            scars.add(new Game("Lamborghini Gallardo","", 2000000D));
            scars.add(new Game("Lamborghini Gallardo","", 2000000D));
            scars.add(new Game("Lamborghini Gallardo","", 2000000D));
            // OU
            //GameRepository.saveAll(cars);
    /*OU
    for(Car car : cars){
        //só fala pra salvar no BD os carros
        carRepository.save(car);

    }*/
            batata.info("Carros criados com sucesso!");
            return;
        }
        batata.warn(String.format("Carros já cadastrados no banco! A tabela possui %s carros.", gamesQtde));

    }
}

