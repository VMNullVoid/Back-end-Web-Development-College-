package br.com.cotemig.mygame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MygameApplicationTests {

    @Test
    void contextLoads() {
    }

}
